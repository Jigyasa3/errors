library(ape)
library(phytools)
#library(devtools)
#install_github("BPerezLamarque/HOME", dependencies = TRUE)
library(HOME)

setwd("C:/Users/81704/Dropbox (OIST)/OIST/Tom'sUnitProject/TomUnit_project/manuscripts/paper2_markergenes/manuscript_submittedProceedingB/Revisions/TSCs_trees_dec2022")

add_host_tips <- function(host_tree, alignment){
  #host_tree$edge.length <- host_tree$edge.length/sum(host_tree$edge.length)
  tip_labels <- host_tree$tip.label[order(nchar(host_tree$tip.label), decreasing = TRUE)]
  list_reads <- c()
  for (i in 1:length(tip_labels)){
    reads <- grep(tip_labels[i], rownames(alignment))
    reads <- reads[!reads %in% list_reads]
    list_reads <- c(list_reads, reads)
    if (length(reads)>0){
      if (!tip_labels[i] %in% rownames(alignment)){ host_tree$tip.label[which(host_tree$tip.label==tip_labels[i])] <-  rownames(alignment)[reads[1]]
      reference_tip <- rownames(alignment)[reads[1]] }else{ reference_tip <- tip_labels[i] }
      reads <- reads[which(!rownames(alignment)[reads] %in% host_tree$tip.label)]
      if (length(reads)>0){
        for (j in 1:length(reads)){
          host_tree <- bind.tip(host_tree, tip.label=rownames(alignment)[reads[j]], edge.length=NULL, where=which(host_tree$tip.label==reference_tip), position=min(0.001,min(host_tree$edge.length)))
        }
      }
    }
  }
  host_tree <- drop.tip(host_tree, tip = host_tree$tip.label[!host_tree$tip.label %in% rownames(alignment)])
  host_tree$edge.length[host_tree$edge.length==0] <- 0.001
  return(force.ultrametric(host_tree,method = "extend"))
}


#alignment file-
alignment<-read.csv(file="2-symbiontheader-d__Archaea_p__Thermoplasmatota_COG0172_tips_1.nwk.txt",header=TRUE) #this is the header of the alignment file
rownames(alignment)<-alignment$onemore

#host tree1-
host_tree<-read.tree(file="rna12-16S_198samples_newnames_jan2023.nwk")
provided_tree <- add_host_tips(host_tree, alignment) #apply the function
write.tree(provided_tree,file="hosttree-beast-d__Archaea_p__Thermoplasmatota_COG0172_tips_1.nwk")

#host tree2-
library(treeio)
host_tree2<-read.iqtree(file="newnames_rooted_ucetermitetree_57p_198samples.nwk")
host_tree2<-host_tree2@phylo

provided_tree2 <- add_host_tips(host_tree2, alignment) #apply the function
write.tree(provided_tree2,file="hosttree-iqtree-d__Archaea_p__Thermoplasmatota_COG0172_tips_1.nwk")

#host tree3-
host_tree3<-read.tree(file="fasttree-rooted-198samples.nwk")

provided_tree3 <- add_host_tips(host_tree3, alignment) #apply the function
write.tree(provided_tree3,file="hosttree-fastree-d__Archaea_p__Thermoplasmatota_COG0172_tips_1.nwk")
